public class InvalidOperatorException extends Exception {

	public InvalidOperatorException(String msg)
	{
		super(msg);
	}
}
